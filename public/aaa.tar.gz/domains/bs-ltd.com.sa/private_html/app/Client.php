<?php

namespace App;


use Illuminate\Database\Eloquent\Model;

class Client  extends Model
{
    protected $table = 'clients';

    protected $hidden = [
    ];
    protected $casts = [

    ];
    protected $guarded = [];


    public static function getRules()
    {
        $rule = [
        ];

        return $rule;
    }




}
