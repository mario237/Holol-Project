<?php

namespace App\Http\Controllers\Admin;

use App\Client;
use App\ClientFile;
use App\ClientStatus;
use App\Http\Controllers\Controller;
use App\Status;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;
use SebastianBergmann\CodeCoverage\TestFixture\C;

class ClientController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $users = User::where([['type', '!=', '4'], ['type', '!=', '0']])->get();
        $status = ClientStatus::all();
        return view('admin.clients', ['users' => $users, 'statuses' => $status]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $obj = new Client();
        $helper = array(
            'method' => 'POST',
            'action' => url('dashboard/clients'),
            'title' => 'انشاء'
        );
        $status = ClientStatus::all();
        $employees = User::where('type', '1')->orWhere('type', '2')->orWhere('type', '3')->get();
        return view('admin.manage.add-edit-client', ['item' => $obj, 'helper' => $helper,
            'statuses' => $status, 'employees' => $employees]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $validator = Validator::make($request->all(), [
            'fullname' => 'required',
            'status' => 'required',
            'bank' => 'required',
            'birthday' => 'required',
            'job' => 'required',
            'mobile' => 'required',
            'support' => 'required',
            'reg_date' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect('dashboard/clients/create')
                ->withErrors($validator)
                ->withInput();
        } else {

            if ($request->password != $request->cpassword) {
                Session::put('successes', ['كلمة المرور غير متطابقة']);
                Session::save();
                return redirect()->back();
            }

            $obj = new Client();
            $obj->fullname = $request->fullname;
            $obj->status = $request->status;
            $obj->users_id = $request->users_id;
            $obj->target_id = $request->users_id;
            $obj->bank = $request->bank;
            $obj->birthday = $request->birthday;
            $obj->job = $request->job;
            $obj->job_type = ($request->job_type) ? $request->job_type : '';
            $obj->mobile = $request->mobile;
            $obj->support = $request->support;
            $obj->note = ($request->note) ? $request->note : '';
            $obj->reg_date = $request->reg_date;
            $obj->salary = ($request->salary) ? $request->salary : '';
            $obj->total_salary = ($request->total_salary) ? $request->total_salary : '';
            $obj->hiring_date = ($request->hiring_date) ? $request->hiring_date : '';
            $obj->commitment = ($request->commitment) ? $request->commitment : '';
            $obj->commitment_remain = ($request->commitment_remain) ? $request->commitment_remain : '';
            $obj->commitment2 = ($request->commitment2) ? $request->commitment2 : '';
            $obj->commitment_remain2 = ($request->commitment_remain2) ? $request->commitment_remain2 : '';
            $obj->self_financing = ($request->self_financing) ? $request->self_financing : '';
            $obj->estate_financing = ($request->estate_financing) ? $request->estate_financing : '';
            $obj->total_financing = ($request->total_financing) ? $request->total_financing : '';
            $obj->pre_installment = ($request->pre_installment) ? $request->pre_installment : '';
            $obj->after_installment = ($request->after_installment) ? $request->after_installment : '';
            $obj->duration = ($request->duration) ? $request->duration : '';
            $obj->save();
            if ($request->images) {
                foreach ($request->images as $file) {
                    $name = time() . '.' . $file->getClientOriginalExtension();
                    $file->move(storage_path('app/public/clients'), $name);
                    $path = 'storage/clients/' . $name;
                    $f = new ClientFile();
                    $f->file = $path;
                    $f->clients_id = $obj->id;
                    $f->save();
                }
            }


            Session::put('successes', ['تمت الاضافة بنجاح']);
            Session::save();
            return redirect('dashboard/clients');
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $obj = Client::where([
            ['clients.id', $id],
        ])->leftJoin('users as u1', 'u1.id', 'clients.users_id')
            ->leftJoin('users as u2', 'u2.id', 'clients.target_id')
            ->join('statuses as s', 's.id', 'clients.status')
            ->select('clients.*', 'u1.name as owner_name', 'u2.name as target_name', 's.title as status_name')->first();

        $obj->files = ClientFile::where('clients_id',$id)->get();

        return view('admin.manage.detail-client', ['item' => $obj]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $validator = Validator::make(['id' => $id], ['id' => 'required|numeric']);

        if ($validator->fails()) {
            return redirect('dashboard/clients')
                ->withErrors($validator);
        } else {
            $obj = Client::find($id);
            $obj->files = ClientFile::where('clients_id',$id)->get();
            $helper = array(
                'method' => 'PUT',
                'action' => url('dashboard/clients/update/' . $id),
                'title' => 'تعديل'
            );
            $status = ClientStatus::all();
            $employees = User::where('type', '1')->orWhere('type', '2')->orWhere('type', '3')->get();
            return view('admin.manage.ajax-edit-client', ['item' => $obj, 'helper' => $helper,
                'statuses' => $status, 'employees' => $employees]);
        }
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request $request
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'fullname' => 'required',
            'status' => 'required',
            'bank' => 'required',
            'birthday' => 'required',
            'job' => 'required',
            'mobile' => 'required',
            'support' => 'required',
            'reg_date' => 'required',
        ]);

        if ($validator->fails()) {
            return redirect("dashboard/clients/$id/edit")
                ->withErrors($validator)
                ->withInput();
        } else {

            $obj = Client::find($id);
            $obj->fullname = $request->fullname;
            $obj->status = $request->status;
            $obj->target_id = $request->target_id;
            $obj->bank = $request->bank;
            $obj->birthday = $request->birthday;
            $obj->job = $request->job;
            $obj->job_type = ($request->job_type) ? $request->job_type : '';
            $obj->mobile = $request->mobile;
            $obj->support = $request->support;
            $obj->note = ($request->note) ? $request->note : '';
            $obj->reg_date = $request->reg_date;
            $obj->salary = ($request->salary) ? $request->salary : '';
            $obj->total_salary = ($request->total_salary) ? $request->total_salary : '';
            $obj->hiring_date = ($request->hiring_date) ? $request->hiring_date : '';
            $obj->commitment = ($request->commitment) ? $request->commitment : '';
            $obj->commitment_remain = ($request->commitment_remain) ? $request->commitment_remain : '';
            $obj->commitment2 = ($request->commitment2) ? $request->commitment2 : '';
            $obj->commitment_remain2 = ($request->commitment_remain2) ? $request->commitment_remain2 : '';
            $obj->self_financing = ($request->self_financing) ? $request->self_financing : '';
            $obj->estate_financing = ($request->estate_financing) ? $request->estate_financing : '';
            $obj->total_financing = ($request->total_financing) ? $request->total_financing : '';
            $obj->pre_installment = ($request->pre_installment) ? $request->pre_installment : '';
            $obj->after_installment = ($request->after_installment) ? $request->after_installment : '';
            $obj->duration = ($request->duration) ? $request->duration : '';
            $obj->update();

            $obj = Client::where([
                ['clients.id', $id],
            ])->leftJoin('users as u1', 'u1.id', 'clients.users_id')
                ->leftJoin('users as u2', 'u2.id', 'clients.target_id')
                ->join('client_status as s', 's.id', 'clients.status')
                ->select('clients.*', 'u1.name as owner_name', 'u2.name as target_name', 's.title as status_name', 's.color as status_color')->first();

            return response()->json($this->getRow($obj))->setStatusCode(200);
        }
    }


    /**
     * Remove the specified resource from storage.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id)
    {
        $obj = Client::find($id);
        $obj->delete();
        return response("success", 200);
    }

    public function addExtra(Request $request)
    {
        $file = $request->image;
        $name = time() . '.' . $file->getClientOriginalExtension();
        $file->move(storage_path('app/public/clients'), $name);
        $path = 'storage/clients/' . $name;
        $f = new ClientFile();
        $f->file = $path;
        $f->clients_id = $request->clients_id;
        $f->save();
        return response(['path'=>$path,'id'=>$f->id], 200);
    }


    public function destroyExtra(Request $request, $id)
    {
        $obj = ClientFile::find($id);
        $obj->delete();
        return response("success", 200);
    }


    public
    function getPaginateData(Request $request)
    {


        $post_data = $request->all();


        $id = Auth::id();
        if (isset($post_data["id"])) {
            $id = $post_data["id"];
        }


        $query = Client::query();
        if ($id != '-1') {
            $query = $query->where([
                ['target_id', $id],
            ]);
        }

        $query = $query->leftJoin('users as u1', 'u1.id', 'clients.users_id')
            ->leftJoin('users as u2', 'u2.id', 'clients.target_id')
            ->join('client_status as s', 's.id', 'clients.status')
            ->select('clients.*', 'u1.name as owner_name', 'u2.name as target_name', 's.title as status_name', 's.color as status_color');

        if (isset($post_data["status_id"]) and $post_data["status_id"] != '' and $post_data["status_id"] != '-1') {
            $query = $query->where('clients.status', $post_data["status_id"]);
        }

        if (isset($post_data["search"]["value"])) {
            $query = $query->where(function ($query) use ($post_data) {
                $query->where('fullname', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('status_name', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('owner_name', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('target_name', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('bank', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('birthday ', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('job ', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('job_type ', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('note ', 'like', '%' . $post_data["search"]["value"] . '%')
                    ->orWhere('updated_at ', 'like', '%' . $post_data["search"]["value"] . '%');
            });
        }

        $orderField = ["id", "fullname", 'status', 'users_id', 'target_id', 'bank', 'birthday', 'job', 'mobile', 'support', 'created_at'];
        if (isset($post_data['order'])) {
            $query->orderBy($orderField[$post_data['order']['0']['column']], $post_data['order']['0']['dir']);
        } else {
            $query->orderBy('id', 'desc');
        }
        $queryWithoutLimit = clone $query;
        if ($post_data['length'] != -1) {
            $query->skip($post_data['start'])->take($post_data['length']);
        }

        $data = array();
        $resutl = $query->get();
        foreach ($resutl as $row) {
            $data[] = $this->getRow($row);
        }

        $output = array(
            "draw" => intval($post_data["draw"]),
            "recordsTotal" => $query->count(),
            "recordsFiltered" => $queryWithoutLimit->count(),
            "data" => $data
        );

        return response(json_encode($output), 200);
    }

    public function getRow($row)
    {
        $sub_array = array();
        $sub_array[] = $row->id;
        $sub_array[] = $row->fullname;
        $sub_array[] = $row->status_name;
        $sub_array[] = $row->owner_name;
        $sub_array[] = $row->target_name;
        $sub_array[] = $row->bank;
        $sub_array[] = ($row->support == '0') ? 'لا' : 'نعم';
        $sub_array[] = $row->reg_date;
        $actions = '<div class="d-flex flex-row flex-wrap">
                                 <a class="btn btn-dark btn-sm text-white  mx-1 btn-view" data-id="' . $row->id . '"><i class="mdi mdi-eye "></i></a>';
        if (Auth::id() == $row->target_id) {

            $actions .= '<a class="btn btn-info btn-sm text-white mx-1 btn-edit" data-id="' . $row->id . '" > <i class="mdi mdi-account-edit "></i> </a>
            <a class="btn btn-danger btn-sm text-white mx-1 btn-delete" data-id="' . $row->id . '"> <i class="mdi mdi-delete "></i> </a>';
        }
        $actions .= '</div> ';
        $sub_array[] = $actions;
        $sub_array[] = $row->status_color;
        return $sub_array;
    }

}
