<html>
<head>
<title>
management.bs-ltd.com.sa</title>
<style>
* { font-family: verdana; font-size: 10pt; COLOR: gray; }
b { font-weight: bold; }
table { border: 1px solid gray;}
td { text-align: center; padding: 25;}
</style>
</head>
<body>
<center>
<br><br><br><br>
<table>
<tr><td>This is a placeholder for the subdomain <b>management.bs-ltd.com.sa</b></td></tr>
</table>
<br><br>
</center>
</body>
</html>