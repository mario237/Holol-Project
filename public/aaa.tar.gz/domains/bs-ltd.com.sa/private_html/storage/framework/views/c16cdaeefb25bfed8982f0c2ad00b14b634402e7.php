<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title">اعدادات الحساب</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item active" aria-current="page">اعدادات الحساب</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-0">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-5">


                        <form action="<?php echo e(url('dashboard/setting')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('PUT')); ?>


                            <div class="form-group row">
                                <label for="name" class="col-sm-2 col-form-label">الاسم الكامل</label>
                                <div class="col-sm-10">
                                    <input required type="text" class="form-control" id="name" placeholder="ادخل اسمك"
                                           name="name" value="<?php echo e($user->name); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="name" class="col-sm-2 col-form-label">البريد الاكتروني </label>
                                <div class="col-sm-10">
                                    <input required type="email" class="form-control" id="name" placeholder="ادخل ايميلك"
                                           name="email" value="<?php echo e($user->email); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-sm-2 col-form-label">كلمة المرور</label>
                                <div class="col-sm-10">
                                    <input  type="password" class="form-control" id="password" name="password"
                                           placeholder="ادخل كلمة المرور">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="cpassword" class="col-sm-2 col-form-label">تأكيد كلمة المرور</label>
                                <div class="col-sm-10">
                                    <input  type="password" class="form-control" id="cpassword" name="cpassword"
                                            placeholder="ادخل التاكيد">
                                </div>
                            </div>

                            <div class="form-group ">
                                <div class="w-100 text-left ">
                                    <button type="submit" class="btn btn-primary">تحديث المعلومات</button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/setting.blade.php ENDPATH**/ ?>