<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="description" content="" />
<meta name="keywords" content="" />
<link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('admin/images/favicon.png')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/bootstrap-rtl.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/owl.theme.default.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('fonts/icomoon/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('fonts/flaticon/font/flaticon.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/daterangepicker.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/aos.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet">


<title>شركه حلول الأعمال المحدودة</title>

<script>
    var base_url = '<?php echo e(url('')); ?>';
</script>







<?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/layout/header.blade.php ENDPATH**/ ?>