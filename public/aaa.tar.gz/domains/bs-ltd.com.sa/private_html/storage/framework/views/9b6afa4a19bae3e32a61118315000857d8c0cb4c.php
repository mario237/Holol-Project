<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title"><?php echo e($helper['title']); ?> موظف</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard/users')); ?>">المستخدمين</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($helper['title']); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-0">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-5">


                        <form action="<?php echo e($helper['action']); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field($helper['method'])); ?>

                            <div class="form-group row">
                                <label for="name" class="col-sm-2 col-form-label">الاسم</label>
                                <div class="col-sm-10">
                                    <input required type="text" class="form-control" id="name" placeholder="ادخل الاسم"
                                           name="name" value="<?php echo e($item->name); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="username" class="col-sm-2 col-form-label">البريد الاكتروني</label>
                                <div class="col-sm-10">
                                    <input required type="email" class="form-control" id="username" name="email"
                                           value="<?php echo e($item->email); ?>"
                                           placeholder="ادخل البريد الاكتروني">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="username" class="col-sm-2 col-form-label">تاريخ الميلاد</label>
                                <div class="col-sm-10">
                                    <input required type="date" class="form-control"  name="birthday"
                                           value="<?php echo e($item->birthday); ?>"
                                           placeholder="ادخل تاريخ الميلاد">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-sm-2 col-form-label">كلمة المرور</label>
                                <div class="col-sm-10">
                                    <input <?php echo e(($helper['method']=='PUT')?'':'required'); ?> type="password"
                                           class="form-control" id="password" name="password"
                                           placeholder="ادخل كلمة المرور">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="password" class="col-sm-2 col-form-label">تأكيد كلمة المرور</label>
                                <div class="col-sm-10">
                                    <input <?php echo e(($helper['method']=='PUT')?'':'required'); ?> type="password"
                                           class="form-control" id="password" name="cpassword"
                                           placeholder="ادخل تاكيد كلمة المرور">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-sm-2 col-form-label"> نوع الموظف </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="type">
                                        <option value="0" <?php echo e(($item->type=='0')?'selected':''); ?>>مستخدم
                                        </option>
                                        <option value="1" <?php echo e(($item->type=='1')?'selected':''); ?>>موظف ادارة عقارات
                                        </option>
                                        <option value="2" <?php echo e(($item->type=='2')?'selected':''); ?>>موظف ادارة تمويل</option>
                                        <option value="3" <?php echo e(($item->type=='3')?'selected':''); ?>>موظف ادارة برمجيات
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password" class="col-sm-2 col-form-label">الادارة </label>
                                <div class="col-sm-10">
                                    <select class="form-control" name="managements_id">
                                        <option value="0" >غير محدد
                                        </option>
                                        <?php $__currentLoopData = $managements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($manage->id); ?>" <?php echo e(($manage->id==$item->managements_id)?'selected':''); ?>><?php echo e($manage->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="name" class="col-sm-2 col-form-label">المسمى الوظيفي</label>
                                <div class="col-sm-10">
                                    <input  type="text" class="form-control" id="job_title" placeholder="ادخل المسمى الوظيفي"
                                           name="job_title" value="<?php echo e($item->job_title); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="name" class="col-sm-2 col-form-label">الرقم الوظيفي</label>
                                <div class="col-sm-10">
                                    <input  type="number" class="form-control" id="job_id" placeholder="ادخل الرقم الوظيفي"
                                           name="job_id" value="<?php echo e($item->job_id); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="name" class="col-sm-2 col-form-label">الكود المرجعي </label>
                                <div class="col-sm-10">
                                    <input  type="text" class="form-control" id="job_id" placeholder="ادخل الكود المرجعي"
                                            name="serial_no" value="<?php echo e($item->serial_no); ?>">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="w-100 d-flex justify-content-between ">
                                    <button type="reset" class="btn btn-dark">مسح البيانات</button>
                                    <button type="submit" class="btn btn-primary"><?php echo e($helper['title']); ?></button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/manage/add-edit-user.blade.php ENDPATH**/ ?>