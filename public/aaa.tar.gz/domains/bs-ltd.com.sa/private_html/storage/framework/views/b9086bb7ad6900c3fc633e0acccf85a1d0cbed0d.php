<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.4/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title">المستخدمون</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item active" aria-current="page">المستخدمون</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">
                <?php if(\Illuminate\Support\Facades\Auth::user()->type=='4'): ?>
                    <div class="text-left upgrade-btn">
                        <a href="<?php echo e(url('dashboard/users/create')); ?>" class="btn btn-primary text-white">
                            <i class="mdi mdi-account-plus"></i>اضافة موظف
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->



    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">ادارة المستخدمين</h4>

                        <form action="<?php echo e(url('dashboard/users')); ?>" method="GET">
                            <div class="row ">
                                <div class="col-md-10 my-1">
                                    <div class="form-group row">
                                        <label for="password" class="col-sm-2 col-form-label"> نوع المستخدم </label>
                                        <div class="col-sm-10">
                                            <select class="form-control" name="type">
                                                <option value="-1" <?php echo e(($type=='-1')?'selected':''); ?>>الكل
                                                </option>
                                                <option value="1" <?php echo e(($type=='1')?'selected':''); ?>>زبائن
                                                </option>
                                                <option value="2" <?php echo e(($type=='2')?'selected':''); ?>>موظفين</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 my-1">
                                    <button type="submit" class="btn btn-primary btn-sm btn-filter m-auto d-block">عرض
                                    </button>
                                </div>
                            </div>
                        </form>
                        <hr/>

                        <div class="table-responsive table-hover mt-5">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">الاسم</th>
                                    <th scope="col">الايميل</th>
                                    <th scope="col">تاريخ الميلاد</th>
                                    <th scope="col">النوع</th>
                                    <th scope="col">الادارة</th>
                                    <th scope="col">الاسم الوظيفي</th>
                                    <th scope="col">الرقم الوظيفي</th>
                                    <th scope="col">الكود المرجعي</th>
                                    <th scope="col">الادوات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $type = 'مستخدم';
                                       if ($user->type=='1'){
                                       $type='موظف عقارات';
                                       }
                                        if ($user->type=='2'){
                                       $type='موظف تمويل';
                                       }
                                       if ($user->type=='3'){
                                       $type='موظف برمجيات';
                                       }
                                    ?>
                                    <tr>
                                        <td><?php echo e($user->id); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td><?php echo e($user->birthday); ?></td>
                                        <td>
                                            <span class="bg-dark p-1 text-white"> <?php echo e($type); ?></span>
                                        </td>
                                        <td><?php echo e(($user->management)?$user->management->name:''); ?></td>
                                        <td><?php echo e(($user->job_title)?$user->job_title:'-'); ?></td>
                                        <td><?php echo e(($user->job_id)?$user->job_id:'-'); ?></td>
                                        <td><?php echo e(($user->serial_no)?$user->serial_no:'-'); ?></td>
                                        <td>
                                            <div class="d-flex flex-row">
                                                <?php if(\Illuminate\Support\Facades\Auth::user()->type=='4'): ?>
                                                    <a class="btn btn-info btn-sm mx-1"
                                                       href="<?php echo e(url('dashboard/users/' . $user->id . '/edit')); ?>">
                                                        <i class="mdi mdi-account-edit "></i>
                                                    </a>
                                                    <form id="delete-form<?php echo e($user->id); ?>"
                                                          action="<?php echo e(url('dashboard/users/' . $user->id)); ?>"
                                                          method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <a class="btn btn-danger mx-1 btn-sm text-white"
                                                       onclick="confirm('Are you sure?')? $('#delete-form<?php echo e($user->id); ?>').submit(): false">
                                                        <i class="mdi mdi-delete"></i>
                                                    </a>
                                                <?php endif; ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

    <script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
    <script>
        $('.table').dataTable();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/users.blade.php ENDPATH**/ ?>