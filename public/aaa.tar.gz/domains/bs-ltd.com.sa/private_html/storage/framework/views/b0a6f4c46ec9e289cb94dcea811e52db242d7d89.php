<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" class="no-js" dir="ltr">
<head>
    <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>

<div class="main-wrapper bg-light">




    <div class="container d-flex justify-content-center ">

        <div class="card p-2 card-primary col-md-5 login " >
            <div class="card-img text-center">
                <img src="<?php echo e(asset('images/logo.jpg')); ?>" class="img-fluid" style="border-radius: 10px" />
            </div>
            <?php echo $__env->make('admin.layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="card-body">
                <form class="form-horizontal form-material" action="<?php echo e(url('dashboard/login')); ?>" method="POST" >
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label class="col-md-12">البريد الاكتروني</label>
                        <div class="col-md-12">
                            <input type="email" required placeholder="" class="form-control form-control-line" name="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-12">كلمة المرور</label>
                        <div class="col-md-12">
                            <input type="password" required placeholder="" class="form-control form-control-line" name="password">
                        </div>
                    </div>

                    <div class="form-group m-t-40">
                        <div class="col-sm-12 text-center">
                            <button type="submit" class="btn btn-primary">تسجيل الدخول</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>


    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</div>

<!-- ============================================================== -->
<!-- End Wrapper -->
<!-- ============================================================== -->

<!-- ============================================================== -->
<!-- All Jquery -->
<!-- ============================================================== -->
<script src="<?php echo e(asset('admin/libs/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap tether Core JavaScript -->
<script src="<?php echo e(asset('admin/libs/popper/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/libs/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/app-style-switcher.js')); ?>"></script>
<!--Wave Effects -->
<script src="<?php echo e(asset('admin/js/waves.js')); ?>"></script>
<!--Menu sidebar -->
<script src="<?php echo e(asset('admin/js/sidebarmenu.js')); ?>"></script>
<!--Custom JavaScript -->
<script src="<?php echo e(asset('admin/js/custom.js')); ?>"></script>

</body>
</html><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/login.blade.php ENDPATH**/ ?>