<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.4/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title">طلبات التمويل</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item active" aria-current="page">طلبات التمويل</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->



    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">ادارة طلبات التمويل</h4>

                        <div class="table-responsive table-hover mt-5">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">الاسم</th>
                                    <th scope="col">الهاتف</th>
                                    <th scope="col">الدعم</th>
                                    <th scope="col">الوظيفة</th>
                                    <th scope="col">نوع التمويل</th>
                                    <th scope="col">تاريخ الطلب</th>
                                    <th scope="col">تمت المعالجة من قبل</th>
                                    <th scope="col">الكود المرجعي </th>
                                    <th scope="col">الادوات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e(($item->seen!='0')?'bg-light-gray':''); ?> ">
                                        <td><?php echo e($item->code); ?></td>
                                        <td><?php echo e($item->fullname); ?></td>
                                        <td><?php echo e($item->phone); ?></td>
                                        <td><?php echo e(($item->support)?"نعم":"لا"); ?></td>
                                        <td><?php echo e($item->job); ?></td>
                                        <td><?php echo e($item->finance_type); ?></td>
                                        <td><?php echo e($item->created_at); ?></td>
                                        <td><?php echo e(($item->seen_name)?$item->seen_name:'-'); ?></td>
                                        <td><?php echo e(($item->ref_code)?$item->ref_code:'-'); ?></td>
                                        <td>
                                            <div class="d-flex flex-row">
                                                <?php if(in_array(\Illuminate\Support\Facades\Auth::user()->type,['2','4'])): ?>
                                                    <a class="btn btn-primary mx-1"
                                                       href="<?php echo e(url('dashboard/orders/financial/' . $item->id)); ?>">
                                                        <i class="mdi mdi-eye "></i>
                                                    </a>

                                                    <form id="delete-form<?php echo e($item->id); ?>"
                                                          action="<?php echo e(url('dashboard/orders/financial/' . $item->id)); ?>"
                                                          method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                    </form>
                                                    <a class="btn btn-danger mx-1 text-white"
                                                       onclick="confirm('Are you sure?')? $('#delete-form<?php echo e($item->id); ?>').submit(): false">
                                                        <i class="mdi mdi-delete"></i>
                                                    </a>

                                                    <?php if($item->seen==0): ?>

                                                        <form id="change-form<?php echo e($item->id); ?>"
                                                              action="<?php echo e(url('dashboard/orders/financial/' . $item->id)); ?>"
                                                              method="POST">
                                                            <input type="hidden" name="seen" value="1">
                                                            <?php echo method_field('PUT'); ?>
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                        <a onclick="$('#change-form<?php echo e($item->id); ?>').submit()" class="btn btn-dark mx-1 text-white btn-sm">
                                                            تحديد كمشاهد
                                                        </a>
                                                    <?php else: ?>
                                                        <span class="btn btn-default btn-sm" style="cursor: auto">
                                                             <i class="mdi mdi-check"></i>
                                                            تمت المشاهدة
                                                        </span>
                                                    <?php endif; ?>

                                                <?php endif; ?>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>


    <script>
        $('.table').dataTable();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/financial-orders.blade.php ENDPATH**/ ?>