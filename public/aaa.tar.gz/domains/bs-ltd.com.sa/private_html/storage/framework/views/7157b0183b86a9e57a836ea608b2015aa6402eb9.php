<?php $__env->startSection('services','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>


    <div class="hero">
        <div class="intro">
            <h1 data-aos="fade-up" data-aos-delay=""> العقارات في <?php echo e($city->name); ?> </h1>
            <p class="text-white">
                شركه حلول الأعمال المحدودة رائده ومتخصصه في المجال العقاري صممت شركة حلول الأعمال المحدودة كل البرامج
                لتلائم ظروف العملاء الفرديه وضمان المرونه القصوى والاستجابه لكل المعاملات
            </p>
        </div>
        <div class="slides overlay">

            <img data-cfsrc="<?php echo e(asset($city->image)); ?>" class="active" alt="Image"/>
        </div>
    </div>




    <div class="untree_co-section">
        <div class="container">
            <div class="row">

                <?php $__currentLoopData = $estates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-md-6 col-lg-4">
                        <div class="job media-1">
                            <div class="head-img">
                                <a href="<?php echo e(url('/services/estates/detail/'.$item->id)); ?>" class="d-block mb-3 ">
                                    <img data-cfsrc="<?php echo e(asset($item->image)); ?>" alt="Image" class="img-fluid">
                                </a>
                            </div>
                            <div class="job-body p-3">
                                <h5><?php echo e($item->title); ?></h5>
                                <div class="d-flex align-items-center loc text-left">
                                    <span class="icon-room "></span>
                                    <span>
                                        <?php echo e($item->address); ?>

                                    </span>
                                </div>

                                <div class="d-block  mt-2 details row">
                                    <div class="d-inline-block item mr-2">
                                    <span class="mr-2 lcolorTxt">
                                        <img src="<?php echo e(asset('images/estate/room.png')); ?>" width="20px">
                                    </span>
                                        <span class="fz-9">عدد الغرف <?php echo e($item->room_num); ?></span>
                                    </div>
                                    <div class="d-inline-block item mr-2">
                                    <span class="mr-2 lcolorTxt">
                                         <img src="<?php echo e(asset('images/estate/entrance.png')); ?>" width="20px">
                                    </span>
                                        <span class="fz-9">المداخل  <?php echo e($item->entrance_num); ?>  </span>
                                    </div>
                                    <div class="d-inline-block item mr-2">
                                    <span class="mr-2 lcolorTxt">
                                        <img src="<?php echo e(asset('images/estate/hole.png')); ?>" width="20px">
                                    </span>
                                        <span class="fz-9">الصالة <?php echo e($item->hole_num); ?> </span>
                                    </div>
                                </div>

                                <div class="d-flex align-items-center justify-content-between mt-3">
                                    <div class="d-inline-block h5 f-bold mt-2">
                                        <span class="text-primary"><?php echo e($item->price); ?></span>
                                        <span class="small">ر.س</span>
                                    </div>
                                    <a href="<?php echo e(url('/services/estates/detail/'.$item->id)); ?>"
                                       class="btn btn-primary btn-sm">مشاهدة التفاصيل</a>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </div>
        </div>
    </div>


    <div class="py-5 bg-primary">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <h2 class="mb-2 text-white">هل لديك ايه مشكلة يمكننا المساعدة في حلها لك </h2>
                    <p class="mb-4 lead text-white text-white-opacity">يمكنك الان التواصل معنا مباشرة من اجل الحصول على
                        استشارات خاصة بكل ما يتعلق بالحلول التمويلية والعقارية</p>
                    <p class="mb-0"><a href="/contactus"
                                       class="btn btn-outline-white text-white btn-md font-weight-bold">اتصل بنا</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <script>

        $('#job').on('change', function () {
            if ($(this).val() === '1') {
                $('#job_type').html('' +
                    '  <option value="0"> قطاع عام</option>\n' +
                    '  <option value="1">  قطاع خاص</option>');
            } else {
                $('#job_type').html('' +
                    '  <option value="0"> عقيد </option>\n' +
                    '  <option value="1">  عميد </option>');
            }
        });
    </script>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/estates-list.blade.php ENDPATH**/ ?>