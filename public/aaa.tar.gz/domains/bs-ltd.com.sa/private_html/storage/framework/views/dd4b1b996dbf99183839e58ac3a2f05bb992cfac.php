<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title"><?php echo e($helper['title']); ?> اعلان</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard/sliders')); ?>">الاعلانات</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($helper['title']); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-0">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-5">


                        <form action="<?php echo e($helper['action']); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field($helper['method'])); ?>



                            <div class="form-group row">
                                <label for="image" class="col-sm-2 col-form-label">الصورة</label>
                                <div class="col-sm-10">
                                    <input <?php echo e(($helper['method']=='PUT')?'':'required'); ?> type="file"
                                           class="form-control" id="image" name="image"
                                           placeholder="اختر الصورة  ">

                                    <?php if($item->image): ?>
                                        <img src="<?php echo e(url($item->image)); ?>" width="100px"/>
                                    <?php endif; ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <div class="w-100 d-flex justify-content-between ">
                                    <button type="reset" class="btn btn-dark">مسح البيانات</button>
                                    <button type="submit" class="btn btn-primary"><?php echo e($helper['title']); ?></button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/manage/add-edit-slider.blade.php ENDPATH**/ ?>