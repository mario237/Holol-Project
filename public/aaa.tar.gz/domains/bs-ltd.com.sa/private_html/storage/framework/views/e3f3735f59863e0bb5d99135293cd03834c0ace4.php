<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" class="no-js" dir="ltr">
<meta http-equiv="content-type" content="text/html;charset=UTF-8"/>
<head>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('page_styles'); ?>


</head>

<body>

<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('main_content'); ?>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('page_scripts'); ?>
</body>
</html><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/layout/master.blade.php ENDPATH**/ ?>