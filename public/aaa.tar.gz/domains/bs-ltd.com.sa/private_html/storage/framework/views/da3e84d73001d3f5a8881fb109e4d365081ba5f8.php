<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>
    <style>
        .bg-blue{
            background-color: rgba(59, 130, 244, 0.4) !important;
        }
        .bg-red{
            background-color: rgba(225, 12, 21, 0.46) !important;
        }
        .bg-green{
            background-color: rgba(63, 183, 31, 0.46)!important;
        }
        .bg-yellow{
            background-color: rgba(183, 180, 22, 0.46)!important;
        }
    </style>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title"><?php echo e($helper['title']); ?> عميل </h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard/clients')); ?>">بيانات العملاء</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($helper['title']); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-0">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-5">


                        <form action="<?php echo e($helper['action']); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field($helper['method'])); ?>


                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">الاسم</label>
                                    <div class="col-sm-12">
                                        <input required type="text" class="form-control" id="title"
                                               placeholder="ادخل الاسم"
                                               name="fullname" value="<?php echo e($item->fullname); ?>">
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">الحالة</label>
                                    <div class="col-sm-12">
                                        <select name="status" class="form-control">
                                            <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option class="bg-<?php echo e($status->color); ?>" value="<?php echo e($status->id); ?>" <?php echo e(($status->id==$item->status)?'selected':''); ?>><?php echo e($status->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">مسؤول العلاقة</label>
                                    <div class="col-sm-12">
                                        <select name="users_id" class="form-control select2">
                                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($emp->id); ?>" <?php echo e(($emp->id==$item->users_id)?'selected':''); ?>><?php echo e($emp->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <?php if($helper['method']=='PUT'): ?>
                                    <div class="form-group col-md-6">
                                        <label for="name" class="col-sm-12 col-form-label">محال الى </label>
                                        <div class="col-sm-12">
                                            <select name="target_id" class="form-control select2">
                                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($emp->id); ?>" <?php echo e(($emp->id==$item->target_id)?'selected':''); ?>><?php echo e($emp->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php
                                    $banks=['مصرف الراجحي','بنك البلاد','بنك الرياض','وزاره الأسكان','بنك الأهلي','بنك سامبا','المعهد العقاري','ساب','بنك الجزيرة']
                                ?>
                                <div class="form-group col-md-6">
                                    <label for="image" class="col-form-label col-sm-12">البنك</label>
                                    <div class="col-sm-12">
                                        <select name="bank" class="form-control select2">
                                            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($emp); ?>" <?php echo e(($emp==$item->bank)?'selected':''); ?>><?php echo e($emp); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> تاريخ الميلاد </label>
                                    <div class="col-sm-12">
                                        <input type="date" class="form-control" id="title"
                                               placeholder="yyyy/mm/dd" required
                                               name="birthday" value="<?php echo e($item->birthday); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6" id="job_container">
                                    <div class="col-sm-12">
                                        <label class="text-black" for="email">الوظيفة</label>
                                        <select id="job" class="form-control" name="job" required>
                                            <option value="عسكري">عسكري</option>
                                            <option value="مدني حكومي"> مدني حكومي</option>
                                            <option value=" قطاع خاص"> قطاع خاص</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-6" id="type_container">
                                    <div class="col-sm-12">
                                        <label class="text-black" for="type">الرتبة</label>
                                        <input type="text" class="form-control" name="job_type">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> رقم الجوال</label>
                                    <div class="col-sm-12">
                                        <input required type="number" class="form-control" id="title"
                                               placeholder="ادخل  رقم الجوال "
                                               name="mobile" value="<?php echo e($item->mobile); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <div class="col-sm-12">
                                        <label class="text-black" for="email">الدعم</label>
                                        <select class="form-control" name="support" required>
                                            <option value="0">لا</option>
                                            <option value="1">نعم</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group col-md-12">
                                    <label for="name" class="col-sm-12 col-form-label"> ملاحظات </label>
                                    <div class="col-sm-12">
                                    <textarea  type="text" class="form-control" id="title"
                                              placeholder="ادخل ملاحظات "
                                              name="note"><?php echo e($item->note); ?></textarea>
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> تاريخ التسجيل </label>
                                    <div class="col-sm-12">
                                        <input required type="date" class="form-control" id="title"
                                               placeholder="ادخل  تاريخ التسجيل "
                                               name="reg_date" value="<?php echo e($item->reg_date); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> الراتب الاساسي </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل  الراتب الاساسي "
                                               name="salary" value="<?php echo e($item->salary); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> اجمالي الراتب </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل  اجمالي الراتب "
                                               name="total_salary" value="<?php echo e($item->total_salary); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> تاريخ التعيين </label>
                                    <div class="col-sm-12">
                                        <input  type="date" class="form-control" id="title"
                                               placeholder="ادخل تاريخ التعيين "
                                               name="hiring_date" value="<?php echo e($item->hiring_date); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">الالتزام </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل  الالتزام "
                                               name="commitment" value="<?php echo e($item->commitment); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">المتبقي على الالتزام </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل  المتبقي على الالتزام "
                                               name="commitment_remain" value="<?php echo e($item->commitment_remain); ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">الالتزام2 </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل  الالتزام2 "
                                               name="commitment2" value="<?php echo e($item->commitment2); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">المتبقي على الالتزام2 </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل  المتبقي على الالتزام2 "
                                               name="commitment_remain2" value="<?php echo e($item->commitment_remain2); ?>">
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">التمويل الشخصي </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل التمويل الشخصي"
                                               name="self_financing" value="<?php echo e($item->self_financing); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">التمويل العقاري </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل التمويل العقاري"
                                               name="estate_financing" value="<?php echo e($item->estate_financing); ?>">
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">اجمالي التمويل </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل اجمالي التمويل"
                                               name="total_financing" value="<?php echo e($item->total_financing); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">القسط قبل الدعم </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل القسط قبل الدعم"
                                               name="pre_installment" value="<?php echo e($item->pre_installment); ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">القسط بعد الدعم </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل القسط بعد الدعم"
                                               name="after_installment" value="<?php echo e($item->after_installment); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">المدة </label>
                                    <div class="col-sm-12">
                                        <input  type="text" class="form-control" id="title"
                                               placeholder="ادخل المدة"
                                               name="duration" value="<?php echo e($item->duration); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-12">
                                    <label for="files" class="col-sm-12 col-form-label">ملفات اخرى </label>
                                    <div class="col-sm-12">
                                        <input  type="file" class="form-control" id="files" multiple
                                                name="images[]" >
                                    </div>
                                </div>

                            </div>
                            <div class="form-group row">
                                <div class="w-100 d-flex justify-content-between ">
                                    <button type="reset" class="btn btn-dark">مسح البيانات</button>
                                    <button type="submit" class="btn btn-primary"><?php echo e($helper['title']); ?></button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>
    <script>

        $('#job').on('change', function () {
            if ($(this).val() === 'عسكري') {
                $('#type_container').removeClass("d-none");
                ;

            } else {
                $('#type_container').addClass("d-none");
                ;
                $('input[name=job_type]').val("");
            }
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/manage/add-edit-client.blade.php ENDPATH**/ ?>