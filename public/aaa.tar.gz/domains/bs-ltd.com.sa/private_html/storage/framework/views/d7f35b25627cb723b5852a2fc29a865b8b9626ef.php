<?php $__env->startSection('services','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>


    <div class="hero" style="    height: 50vh;overflow: hidden;min-height: auto">
        <div class="intro">
            <h1 data-aos="fade-up" data-aos-delay=""> شقق للبيع في جدة </h1>

        </div>
        <div class="slides overlay">


        </div>
    </div>
    <?php echo $__env->make('layout.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <div class="untree_co-section estate">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">

                    <h2 class="section-title mb-2"><?php echo e($estate->title); ?></h2>

                    <div class=" mb-3 " style="direction: ltr;min-height: 50vh">
                        <div class="owl-single dots-absolute owl-carousel " style="min-height: 50vh">

                            <?php for($i=0;$i<count($estate->images);$i++): ?>
                                <img src="<?php echo e(asset($estate->images[$i]->src)); ?>" class="img-fluid <?php echo e(($i==0)?'active':''); ?>"
                                >
                            <?php endfor; ?>


                        </div>
                    </div>

                    <p>
                        <?php echo e($estate->description); ?>

                    </p>


                    <a href="<?php echo e($estate->map); ?>" target="_blank"
                       class="btn btn-primary btn-sm mt-2">عرض الموقع على الخريطة</a>
                    <div class="d-inline-block h5 f-bold mt-2 float-left">
                        <span class=" h4">السعر : </span>
                        <span class="text-primary h4"> <?php echo e($estate->price); ?></span>
                        <span class="small">ر.س</span>
                    </div>

                </div>
                <div class="col-lg-5">
                    <div class="row">

                        <div class="col-md-12 ">
                            <h5>نظرة عامة</h5>
                            <div class="col-12 fz-12 f-bold mb-3 justify-content-center">
                                <div class="d-block item ">
                                    <span><img src="<?php echo e(asset('images/estate/room.png')); ?>"
                                               alt="" class="mr-2"> عدد الغرف</span>
                                    <span class="fl-left "> <?php echo e(($estate->room_num)?$estate->room_num:'-'); ?></span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/hole.png')); ?>"
                                               alt="" class="mr-2"> الصالة</span>
                                    <span class="fl-left "><?php echo e(($estate->hole_num)?$estate->hole_num:'-'); ?></span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/bath.png')); ?>"
                                               alt="" class="mr-2"> عدد دورات المياه</span>
                                    <span class="fl-left "><?php echo e(($estate->bath_num)?$estate->bath_num:'-'); ?></span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/kitchen.png')); ?>"
                                               alt="" class="mr-2"> مطبخ</span>
                                    <span class="fl-left "><?php echo e(($estate->kitchen_num)?$estate->kitchen_num:'-'); ?> </span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/entrance.png')); ?>"
                                               alt="" class="mr-2"> مدخل</span>
                                    <span class="fl-left "><?php echo e(($estate->enterance_num)?$estate->enterance_num:'-'); ?> </span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/area.png')); ?>"
                                               alt="" class="mr-2"> مساحة البناء</span>
                                    <span class="fl-left "><?php echo e(($estate->area)?$estate->area:'-'); ?> </span>
                                </div>

                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/area.png')); ?>"
                                               alt="" class="mr-2"> مساحة الارض</span>
                                    <span class="fl-left "><?php echo e(($estate->ground_area)?$estate->ground_area:'-'); ?> </span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/area.png')); ?>"
                                               alt="" class="mr-2"> مساحة الشارع</span>
                                    <span class="fl-left "><?php echo e(($estate->street_area)?$estate->street_area:'-'); ?> </span>
                                </div>

                                    <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/area.png')); ?>"
                                               alt="" class="mr-2">مساحة الشارع 2</span>
                                        <span class="fl-left "> <?php echo e(($estate->street_area2)?$estate->street_area2:'-'); ?></span>
                                    </div>


                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/driver.png')); ?>"
                                               alt="" class="mr-2"> غرفة السائق</span>
                                    <span class="fl-left "><i
                                                class="fas  <?php echo e(($estate->driver_room)?'fa-check':'fa-times'); ?>"></i></span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/service.png')); ?>"
                                               alt="" class="mr-2"> غرفة خادمة</span>
                                    <span class="fl-left "><i
                                                class="fas <?php echo e(($estate->maid_room)?'fa-check':'fa-times'); ?>"></i></span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/left.png')); ?>"
                                               alt="" class="mr-2"> مصعد</span>
                                    <span class="fl-left "><i
                                                class="fas <?php echo e(($estate->left_num)?'fa-check':'fa-times'); ?>"></i></span>
                                </div>
                                <div class="d-block item">
                                    <span><img src="<?php echo e(asset('images/estate/water.png')); ?>"
                                               alt="" class="mr-2"> خزان مياه مستقل</span>
                                    <span class="fl-left "><i
                                                class="fas <?php echo e(($estate->watertank_num)?'fa-check':'fa-times'); ?>"></i></span>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>


    <div class="untree_co-section">
        <div class="container">
            <div class="row justify-content-center mb-5">
                <div class="col-md-6 text-center">
                    <h2 class="section-title mb-3 text-center">تقديم طلب</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="row">
                        <div class="col-md-12">

                            <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                                <form class="contact-form" data-aos="fade-up" method="POST"
                                      action="<?php echo e(url('/estate-request')); ?>">
                                    <input type="hidden" value="<?php echo e($estate->id); ?>" name="id">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group ">
                                                <label class="text-black" for="fname">الاسم الاول</label>
                                                <input type="text" class="form-control" id="fname" name="fname"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="text-black" for="lname">الاسم الاخير</label>
                                                <input type="text" class="form-control" id="lname" name="lname"
                                                       required>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="text-black" for="phone">رقم الجوال</label>
                                                <input type="tel" class="form-control" id="phone" name="phone" required>
                                            </div>

                                        </div>

                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label class="text-black" for="ref_code">الرقم المرجعي </label>
                                                <input type="text" class="form-control" id="ref_code" name="ref_code" >
                                            </div>

                                        </div>


                                    </div>

                                    <div class="alert alert-success">
                                        <div class="alert-heading">
                                            سيقوم فريق تسويق والمبيعات بالتواصل معك
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-primary">ارسال طلب</button>
                                </form>

                            <?php else: ?>
                                <div class="text-center">
                                    <h4>يجب عليك تسجيل الدخول لتتمكن من ارسال الطلب</h4>
                                    <a class="btn btn-primary m-4" href="<?php echo e(url('/signup')); ?>">تسجيل الدخول \ انشاء
                                        حساب</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="py-5 bg-primary">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <h2 class="mb-2 text-white">هل لديك ايه مشكلة يمكننا المساعدة في حلها لك </h2>
                    <p class="mb-4 lead text-white text-white-opacity">يمكنك الان التواصل معنا مباشرة من اجل الحصول على
                        استشارات خاصة بكل ما يتعلق بالحلول التمويلية والعقارية</p>
                    <p class="mb-0"><a href="/contactus"
                                       class="btn btn-outline-white text-white btn-md font-weight-bold">اتصل بنا</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <script>

        $('#job').on('change', function () {
            if ($(this).val() === '1') {
                $('#job_type').html('' +
                    '  <option value="0"> قطاع عام</option>\n' +
                    '  <option value="1">  قطاع خاص</option>');
            } else {
                $('#job_type').html('' +
                    '  <option value="0"> عقيد </option>\n' +
                    '  <option value="1">  عميد </option>');
            }
        });
    </script>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/estate-detail.blade.php ENDPATH**/ ?>