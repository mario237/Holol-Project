<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title"><?php echo e($helper['title']); ?> عقار </h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard/estates')); ?>">العقارات</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?php echo e($helper['title']); ?></li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->

    <?php if($errors->any()): ?>
        <div class="alert alert-danger mb-0">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>


    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body p-5">


                        <form action="<?php echo e($helper['action']); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field($helper['method'])); ?>



                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">الاسم</label>
                                    <div class="col-sm-12">
                                        <input required type="text" class="form-control" id="title"
                                               placeholder="ادخل الاسم"
                                               name="title" value="<?php echo e($item->title); ?>">
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">العنوان</label>
                                    <div class="col-sm-12">
                                        <input required type="text" class="form-control" id="title"
                                               placeholder="ادخل العنوان"
                                               name="address" value="<?php echo e($item->address); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">السعر</label>
                                    <div class="col-sm-12">
                                        <input required type="text" class="form-control" id="title"
                                               placeholder="ادخل السعر"
                                               name="price" value="<?php echo e($item->price); ?>">
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="image" class="col-sm-12 col-form-label">الصورة</label>
                                    <div class="col-sm-12">
                                        <input <?php echo e(($helper['method']=='PUT')?'':'required'); ?> type="file"
                                               class="form-control" id="image" name="image"
                                               placeholder="اختر الصورة  ">

                                        <?php if($item->image): ?>
                                            <img src="<?php echo e(url($item->image)); ?>" width="100px"/>
                                        <?php endif; ?>
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> نوع الاضافة </label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="add_type">
                                            <option value="0" <?php echo e(($item->add_type=='0')?'selected':''); ?>>مباشر
                                            </option>
                                            <option value="1" <?php echo e(($item->add_type=='1')?'selected':''); ?>> غير مباشر</option>
                                        </select>
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">الموقع على الخريطة</label>
                                    <div class="col-sm-12">
                                        <input  type="url" class="form-control" id="title"
                                                placeholder="ادخل الرابط"
                                                name="map" value="<?php echo e($item->map); ?>">
                                    </div>
                                </div>


                                <div class="form-group col-md-12">
                                    <label for="name" class="col-sm-12 col-form-label"> الوصف </label>
                                    <div class="col-sm-12">
                                    <textarea required type="text" class="form-control" id="title"
                                              placeholder="ادخل الوصف "
                                              name="description"><?php echo e($item->description); ?></textarea>
                                    </div>
                                </div>


                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> عدد الغرف </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  عدد الغرف"
                                               name="room_num" value="<?php echo e($item->room_num); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> عدد الصالات </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  عدد الصالات"
                                               name="hole_num" value="<?php echo e($item->hole_num); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> عدد دورات المياه </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  عدد دورات المياه"
                                               name="bath_num" value="<?php echo e($item->bath_num); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> عدد المطابخ </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  عدد المطابخ "
                                               name="kitchen_num" value="<?php echo e($item->kitchen_num); ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> عدد المداخل </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  عدد المداخل "
                                               name="enterance_num" value="<?php echo e($item->enterance_num); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> مساحة البناء </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  مساحة البناء "
                                               name="area" value="<?php echo e($item->area); ?>">
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> مساحة الارض </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  مساحة الارض "
                                               name="ground_area" value="<?php echo e($item->ground_area); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> مساحة الشارع </label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  مساحة الشارع "
                                               name="street_area" value="<?php echo e($item->street_area); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> مساحة الشارع 2</label>
                                    <div class="col-sm-12">
                                        <input  type="number" class="form-control" id="title"
                                               placeholder="ادخل  مساحة الشارع 2 "
                                               name="street_area2" value="<?php echo e($item->street_area2); ?>">
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> غرفة السائق </label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="driver_room">
                                            <option value="0" <?php echo e(($item->driver_room=='0')?'selected':''); ?>>غير موجود
                                            </option>
                                            <option value="1" <?php echo e(($item->driver_room=='1')?'selected':''); ?>> موجود
                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> غرفة الخادمة </label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="maid_room">
                                            <option value="0" <?php echo e(($item->maid_room=='0')?'selected':''); ?>>غير موجود
                                            </option>
                                            <option value="1" <?php echo e(($item->maid_room=='1')?'selected':''); ?>> موجود</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> المصعد </label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="left_num">
                                            <option value="0" <?php echo e(($item->left_num=='0')?'selected':''); ?>>غير موجود
                                            </option>
                                            <option value="1" <?php echo e(($item->left_num=='1')?'selected':''); ?>> موجود</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label"> خزان مياه مستقل </label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="watertank_num">
                                            <option value="0" <?php echo e(($item->watertank_num=='0')?'selected':''); ?>>غير موجود
                                            </option>
                                            <option value="1" <?php echo e(($item->watertank_num=='1')?'selected':''); ?>> موجود
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="name" class="col-sm-12 col-form-label">المنطقة </label>
                                    <div class="col-sm-12">
                                        <select class="form-control" name="cities_id">
                                            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($city->id); ?>" <?php echo e(($item->cities_id==$city->id)?'selected':''); ?>><?php echo e($city->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>

                            </div>
                            <div class="form-group row">
                                <div class="w-100 d-flex justify-content-between ">
                                    <button type="reset" class="btn btn-dark">مسح البيانات</button>
                                    <button type="submit" class="btn btn-primary"><?php echo e($helper['title']); ?></button>
                                </div>
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/manage/add-edit-estate.blade.php ENDPATH**/ ?>