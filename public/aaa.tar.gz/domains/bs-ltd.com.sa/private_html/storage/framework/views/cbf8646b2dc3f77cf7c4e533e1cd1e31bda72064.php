<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.4/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title">الاعلانات</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item active" aria-current="page">الاعلانات</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">
                <div class="text-left upgrade-btn">
                    <a href="<?php echo e(url('dashboard/sliders/create')); ?>" class="btn btn-primary text-white">
                        <i class="mdi mdi-account-plus"></i>اضافة اعلان
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->



    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">ادارة الاعلانات</h4>

                        <div class="table-responsive table-hover mt-5">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">الصورة</th>
                                    <th scope="col">الادوات</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->id); ?></td>
                                        <td><img src="<?php echo e(url($item->image)); ?>" height="100px"/></td>
                                        <td>
                                            <div class="d-flex flex-row">
                                                <a class="btn btn-info mx-1"
                                                   href="<?php echo e(url('dashboard/sliders/' . $item->id . '/edit')); ?>">
                                                    <i class="mdi mdi-account-edit "></i>
                                                </a>
                                                <form id="delete-form<?php echo e($item->id); ?>"
                                                      action="<?php echo e(url('dashboard/sliders/' . $item->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                </form>
                                                <a class="btn btn-danger mx-1 text-white"
                                                   onclick="confirm('Are you sure?')? $('#delete-form<?php echo e($item->id); ?>').submit(): false">
                                                    <i class="mdi mdi-delete"></i>
                                                </a>

                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

    <script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
    <script>
        $('.table').dataTable();
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/sliders.blade.php ENDPATH**/ ?>