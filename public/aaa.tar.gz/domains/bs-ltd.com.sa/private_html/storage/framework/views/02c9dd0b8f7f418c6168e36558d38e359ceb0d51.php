<style>
    label {
        font-size: 14px;
    }

    h6 {
        font-size: 15px;
    }
</style>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="section-title mb-3">تفاصيل العميل </h5>
                        <hr/>
                        <div class="row">
                            <div class="form-group col-md-3">
                                <label class=" text-muted">الاسم الثلاثي</label>
                                <h6><?php echo e($item->fullname); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">حالة الطلب</label>
                                <h6><?php echo e($item->status_name); ?> </h6>
                            </div>

                            <div class="form-group col-md-3">
                                <label class=" text-muted">مسؤول العلاقة </label>
                                <h6><?php echo e($item->owner_name); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">محال الى </label>
                                <h6><?php echo e($item->target_name); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted"> البنك </label>
                                <h6><?php echo e($item->bank); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted"> تاريخ الميلاد </label>
                                <h6><?php echo e($item->birthday); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">الوظيفه </label>
                                <h6><?php echo e($item->job); ?> <?php echo e(($item->job_type!='')?' - '.$item->job_type:''); ?>  </h6>
                            </div>

                            <div class="form-group col-md-3">
                                <label class=" text-muted"> رقم الجوال </label>
                                <h6><?php echo e($item->mobile); ?> </h6>
                            </div>

                            <div class="form-group col-md-3">
                                <label class=" text-muted">الدعم </label>
                                <h6><?php echo e(($item->support=='0')?'لا':'نغم'); ?>  </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">ملاحظات </label>
                                <h6><?php echo e($item->note); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">تاريخ تسجيل الطلب </label>
                                <h6><?php echo e($item->reg_date); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">الراتب الاساسي </label>
                                <h6><?php echo e($item->salary); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">اجمالي الراتب </label>
                                <h6><?php echo e($item->total_salary); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">تاريخ التعيين </label>
                                <h6><?php echo e($item->hiring_date); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">الالتزام</label>
                                <h6><?php echo e($item->commitment); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">المتبقي على الالتزام</label>
                                <h6><?php echo e($item->commitment_remain); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">الالتزام </label>
                                <h6><?php echo e($item->commitment2); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">المتبقي على الالتزام</label>
                                <h6><?php echo e($item->commitment_remain2); ?> </h6>
                            </div>

                            <div class="form-group col-md-3">
                                <label class=" text-muted">التمويل الشخصي </label>
                                <h6><?php echo e($item->self_financing); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">التمويل العقاري </label>
                                <h6><?php echo e($item->estate_financing); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">اجمالي التمويل </label>
                                <h6><?php echo e($item->total_financing); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">القسط قبل الدعم </label>
                                <h6><?php echo e($item->pre_installment); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">القسط بعد الدعم</label>
                                <h6><?php echo e($item->after_installment); ?> </h6>
                            </div>
                            <div class="form-group col-md-3">
                                <label class=" text-muted">المدة</label>
                                <h6><?php echo e($item->duration); ?> </h6>
                            </div>

                            <div class="form-group col-md-3">
                                <label class=" text-muted">ملفات اخرى</label>
                                <div class="d-block">
                                    <?php if(count($item->files)==0): ?>
                                        <h6>لا يوجد </h6>
                                    <?php endif; ?>
                                    <?php $__currentLoopData = $item->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="d-inline-block" target="_blank" href="<?php echo e(url($file->file)); ?>">اضغط هنا
                                            لفتح الملف</a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/manage/detail-client.blade.php ENDPATH**/ ?>