<?php $__env->startSection('services','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>


    <div class="hero inner">
        <div class="intro">
            <h1 data-aos="fade-up" data-aos-delay=""> خدمة العقارات</h1>
            <p class="text-white">
                تقدم شركة حلول الاعمال مشاريع ذات مستوى عالي من التنفيذ والدقة والجمع بين التصميم الأنيق ووسائل الراحة
                العصرية الحديثة في جميع مناطق المملكة

            </p>
        </div>
        <div class="slides overlay">

            
                 
        </div>
    </div>


    <div class="untree_co-section">
        <div class="container">
            <div class="row align-content-lg-center">
                <div class="col-md-8 col-sm-12">
                    <h2 class="section-title mb-3">نقدم أفضل العقارات</h2>
                    <p>

                        توفر شركة حلول الاعمال عقارات في العديد من المدن في المملكة
                        تقدم شركة حلول الاعمال العقارية مشاريع ذات مستوى عالي من التنفيذ والدقة والجمع بين التصميم
                        الأنيق ووسائل الراحة العصرية الحديثة في جميع مناطق المملكة ويهدف إلى تلبية احتياجات الأفراد
                        والعائلات وإيجاد حلول سكنية تمكن عملائنا من تملك المنزل المناسب والانتفاع بها وفق احتياجاتهم
                        وقدراتهم المادية، وذلك من خلال توفير حلول تمويلية ملائمة تناسب الجميع.
                    </p>
                </div>
                <div class="col-md-4 d-sm-none d-md-block text-left">
                    <div class="row">
                        <img data-cfsrc="<?php echo e(asset('images/services/estates_inner.png')); ?>" alt="Image"
                             class="img-fluid w-50 m-auto ">

                    </div>
                </div>
            </div>
        </div>
    </div>



    <div class="untree_co-section">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-12 col-md-6 col-lg-4">
                        <a href="<?php echo e(url('/services/estates/'.$item->id)); ?>" class="media-1" style="margin-top: 2em">
                            <img data-cfsrc="<?php echo e(asset($item->image)); ?>" alt="Image" class="img-fluid">

                            <div class="media-body">
                                <div class="title">
                                    <h2><?php echo e($item->name); ?></h2>
                                </div>

                            </div>

                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </div>


    <div class="py-5 bg-primary">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12">
                    <h2 class="mb-2 text-white">هل لديك ايه مشكلة يمكننا المساعدة في حلها لك </h2>
                    <p class="mb-4 lead text-white text-white-opacity">يمكنك الان التواصل معنا مباشرة من اجل الحصول على
                        استشارات خاصة بكل ما يتعلق بالحلول التمويلية والعقارية</p>
                    <p class="mb-0"><a href="/contactus"
                                       class="btn btn-outline-white text-white btn-md font-weight-bold">اتصل بنا</a>
                    </p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_scripts'); ?>
    <script>

        $('#job').on('change', function () {
            if ($(this).val() === '1') {
                $('#job_type').html('' +
                    '  <option value="0"> قطاع عام</option>\n' +
                    '  <option value="1">  قطاع خاص</option>');
            } else {
                $('#job_type').html('' +
                    '  <option value="0"> عقيد </option>\n' +
                    '  <option value="1">  عميد </option>');
            }
        });
    </script>

<?php $__env->stopSection(); ?>










<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/estates.blade.php ENDPATH**/ ?>