<?php $__env->startSection('home','active'); ?>
<?php
    $lang=app()->getLocale()
?>

<?php $__env->startSection('page_styles'); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('main_content'); ?>

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title">اللوحة</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('dashboard')); ?>">اللوحة</a></li>
                            <li class="breadcrumb-item active" aria-current="page">الرئيسية</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">

            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->



    <div class="container-fluid mt-5">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <a class="col-md-6 col-sm-6" href="<?php echo e(url('dashboard/users')); ?>">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center flex-row ">
                            <div class="display-3 text-white bg-primary2 p-4"><i class="mdi mdi-account"></i></div>
                            <div class="mx-auto ">
                                <h3 class="m-b-0 text-primary display-4 text-center"><?php echo e($statistic['users']); ?></h3>
                                <h5 class="text-dark"> المستخدمون المسجلون</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>

            <a class="col-md-6 col-sm-6" href="<?php echo e(url('dashboard/orders/programming')); ?>">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center flex-row ">
                            <div class="display-3 text-white bg-primary2 p-4"><i class="mdi mdi-table-edit"></i></div>
                            <div class="mx-auto">
                                <h3 class="m-b-0 text-dark display-4 text-center"><?php echo e($statistic['programming_request']); ?></h3>
                                <h5 class="text-dark"> طلبات البرمجية</h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>

            <a class="col-md-6 col-sm-6" href="<?php echo e(url('dashboard/orders/estates')); ?>">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center flex-row ">
                            <div class="display-3 text-white bg-primary2 p-4"><i class="mdi mdi-table-edit"></i></div>
                            <div class="mx-auto">
                                <h3 class="m-b-0 text-primary display-4 text-center"><?php echo e($statistic['estate_requests']); ?></h3>
                                <h5 class="text-dark"> طلبات العقارات </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>


            <a class="col-md-6 col-sm-6" href="<?php echo e(url('dashboard/orders/financial')); ?>">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center flex-row ">
                            <div class="display-3 text-white bg-primary2 p-4"><i class="mdi mdi-table-edit"></i></div>
                            <div class="mx-auto">
                                <h3 class="m-b-0 text-primary display-4 text-center"><?php echo e($statistic['financial_request']); ?></h3>
                                <h5 class="text-dark"> طلبات التمويل </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
            <a class="col-md-6 col-sm-6" href="<?php echo e(url('dashboard/regions')); ?>">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center flex-row ">
                            <div class="display-3 text-white bg-primary2 p-4"><i class="mdi mdi-earth"></i></div>
                            <div class="mx-auto">
                                <h3 class="m-b-0 text-primary display-4 text-center"><?php echo e($statistic['cities']); ?></h3>
                                <h5 class="text-dark"> المناطق  </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>


            <a class="col-md-6 col-sm-6" href="<?php echo e(url('dashboard/estates')); ?>">
                <div class="card">
                    <div class="card-body p-0">
                        <div class="d-flex align-items-center flex-row ">
                            <div class="display-3 text-white bg-primary2 p-4"><i class="mdi mdi-hospital-building"></i></div>
                            <div class="mx-auto">
                                <h3 class="m-b-0 text-primary display-4 text-center"><?php echo e($statistic['estates']); ?></h3>
                                <h5 class="text-dark"> العقارات  </h5>
                            </div>
                        </div>
                    </div>
                </div>
            </a>

        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->



    </div>

<?php $__env->stopSection(); ?>






<!-- ---------------------------------------------------- -->

<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>