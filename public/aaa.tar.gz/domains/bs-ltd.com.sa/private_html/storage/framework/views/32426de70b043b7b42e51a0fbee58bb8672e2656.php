<?php
    $_errors =   \Illuminate\Support\Facades\Session::get('_errors');
    $_successes =   \Illuminate\Support\Facades\Session::get('successes');
    \Illuminate\Support\Facades\Session::remove('_errors');
    \Illuminate\Support\Facades\Session::remove('successes');
if (!$_errors){$_errors = array();}
if (!$_successes){$_successes = array();}

?>


<?php $__currentLoopData = $_errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="alert alert-danger alert-dismissible text-center  m-0" role="alert" style="position: relative">
            <?php echo e($error); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = $_successes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $success): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="alert alert-success alert-dismissible text-center  m-0" role="alert" style="position: relative;">
        <?php echo e($success); ?>

        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /home/bsltdcom/domains/bs-ltd.com.sa/private_html/resources/views/layout/message.blade.php ENDPATH**/ ?>