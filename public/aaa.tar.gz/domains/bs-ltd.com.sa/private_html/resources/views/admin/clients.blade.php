@extends('admin.layout.master')

@section('home','active')
@php
    $lang=app()->getLocale()
@endphp

@section('page_styles')

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.4/css/jquery.dataTables.min.css">
    <style>
        .bg-blue {
            background-color: rgba(59, 130, 244, 0.4) !important;
        }

        .bg-red {
            background-color: rgba(225, 12, 21, 0.46) !important;
        }

        .bg-green {
            background-color: rgba(63, 183, 31, 0.46) !important;
        }

        .bg-yellow {
            background-color: rgba(183, 180, 22, 0.46) !important;
        }
    </style>
@endsection



@section('main_content')

    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="page-breadcrumb">
        <div class="row align-items-center">
            <div class="col-5">
                <h4 class="page-title">بيانات العملاء</h4>
                <div class="d-flex align-items-center">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('dashboard')}}">اللوحة</a></li>
                            <li class="breadcrumb-item active" aria-current="page">بيانات العملاء</li>
                        </ol>
                    </nav>
                </div>
            </div>
            <div class="col-7">
                <div class="text-left upgrade-btn">
                    <a href="{{url('dashboard/clients/create')}}" class="btn btn-primary text-white">
                        <i class="mdi mdi-account-plus"></i>اضافة عميل
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->



    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Start Page Content -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">ادارة بيانات العملاء</h4>
                        <hr/>

                        <div class="row ">
                            <div class="col-md-5 my-1">
                                <select id="users_id" class="select2 form-control m-auto">
                                    <option value="-1">الكل</option>
                                    @foreach($users as $emp)
                                        <option value="{{$emp->id}}" {{($emp->id==\Illuminate\Support\Facades\Auth::id())?'selected':''}}>{{$emp->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-5 my-1">
                                <select id="status_id" class="select2 form-control m-auto">
                                    <option value="-1">الكل</option>
                                    @foreach($statuses as $emp)
                                        <option value="{{$emp->id}}">{{$emp->title}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2 my-1">
                                <button class="btn btn-primary btn-sm btn-filter m-auto d-block">عرض بيانات العملاء
                                </button>
                            </div>
                        </div>
                        <hr/>

                        <div class="table-responsive table-hover mt-5">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">الاسم</th>
                                    <th scope="col">حالة الطلب</th>
                                    <th scope="col">مسؤول العلاقة</th>
                                    <th scope="col">محال الى</th>
                                    <th scope="col">البنك</th>
                                    <th scope="col">الدعم</th>
                                    <th scope="col">تاريخ التسجيل</th>
                                    <th scope="col">الادوات</th>
                                </tr>
                                </thead>
                                <tbody>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- End PAge Content -->
        <!-- ============================================================== -->
    </div>

@endsection






<!-- ---------------------------------------------------- -->

@section('page_scripts')

    <script src="https://cdn.datatables.net/1.10.4/js/jquery.dataTables.min.js"></script>
    <script>
        var user_id = '';
        var status_id = '';
        $(document).ready(function () {
            user_id = $('#users_id').val();
            var token = $('meta[name="csrf-token"]').attr('content');
            datatable = $('.table').DataTable({
                responsive: true,
                "processing": true,
                "serverSide": true,
                "order": [],
                "ordering": false,
                "columnDefs": [
                    {
                        "targets": [8],
                        "visible": true,
                        "searchable": false
                    },
                    {
                        "targets": [9],
                        "visible": false,
                        "searchable": false
                    },
                ],
                "ajax": {
                    url: base_url + "/dashboard/clients/paginate",
                    type: "POST",
                    data: function (data) {
                        data._token = token;
                        data.id = user_id
                        data.status_id = status_id

                    }
                },
                "createdRow": function (row, data, dataIndex) {
                    // alert(data[9]);
                    $(row).addClass('bg-' + data[9]);
                }
            });
        });
        $(document).delegate('.btn-filter', 'click', function (e) {
            e.preventDefault();
            user_id = $('#users_id').val();
            status_id = $('#status_id').val();
            datatable.ajax.reload();

        });
        $(document).delegate('.btn-delete', 'click', function (e) {
            e.preventDefault();
            if (confirm("هل انت متأكد انك تريد الجذف ؟")) {
                id = $(this).data('id');
                var tr = $(this).closest('tr');
                var row = datatable.row(tr);

                url = base_url + '/dashboard/clients/delete/' + id;
                var token = $('meta[name="csrf-token"]').attr('content');
                $.ajax({
                    url: base_url + "/dashboard/clients/" + id,
                    type: 'POST',
                    data: {
                        "_token": token,
                        "_method": 'DELETE',
                    },
                    success: function (result) {
                        if (result == 'success') {
                            alert("تم الحذف بنجاح");
                            row.remove().draw();
                        }
                    },
                    error: function (request, msg, error) {
                        alert("لا تملك الصلاحية لحذف هذا السجل")
                    }
                });
            }
        });

        $(document).delegate('.btn-delete-file', 'click', function (e) {
            e.preventDefault();
            if (confirm("هل انت متأكد انك تريد الجذف ؟")) {
                id = $(this).data('id');
                var container = $(this).closest('.file');

                url = base_url + '/dashboard/clients/extra/delete/' + id;
                var token = $('meta[name="csrf-token"]').attr('content');
                $.ajax({
                    url: url,
                    type: 'POST',
                    data: {
                        "_token": token,
                        "_method": 'DELETE',
                    },
                    success: function (result) {
                        if (result == 'success') {
                            alert("تم الحذف بنجاح");
                            container.remove();
                        }
                    },
                    error: function (request, msg, error) {
                        alert("لا تملك الصلاحية لحذف هذا السجل")
                    }
                });
            }
        });


        $(document).delegate('.btn-view', 'click', function (e) {
            e.preventDefault();

            id = $(this).data('id');
            var tr = $(this).closest('tr');
            parent = $(this).closest('td');
            var row = datatable.row(tr);

            if (row.child.isShown()) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
                tr.removeClass('bg-light');
            }
            else {
                // Open this row
                loadDetail(id, function (data) {
                    row.child(data).show();
                    tr.addClass('shown');
                    tr.addClass('bg-light');
                });

            }

        });

        function loadDetail(id, callback) {
            var token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: base_url + "/dashboard/clients/" + id,
                type: 'GET',
                data: {
                    "_token": token,
                },
                success: function (result) {
                    callback(result)
                },
                error: function (request, msg, error) {
                    callback('<div class="alert alert-danger text-center"> <h5>لا تملك الصلاحية لتحميل هذا السجل</h5></div>')
                }
            });
        }


        $(document).delegate('.btn-edit', 'click', function (e) {
            e.preventDefault();

            id = $(this).data('id');
            var tr = $(this).closest('tr');
            parent = $(this).closest('td');
            var row = datatable.row(tr);

            if (row.child.isShown()) {
                // This row is already open - close it
                row.child.hide();
                tr.removeClass('shown');
                tr.removeClass('bg-light');
            }
            else {
                // Open this row
                loadEditDetail(id, function (data) {
                    row.child(data).show();
                    tr.addClass('shown');
                    tr.addClass('bg-light');
                });

            }

        });

        function loadEditDetail(id, callback) {
            var token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: base_url + "/dashboard/clients/" + id + "/edit",
                type: 'GET',
                data: {
                    "_token": token,
                },
                success: function (result) {
                    callback(result)
                },
                error: function (request, msg, error) {
                    callback('<div class="alert alert-danger text-center"> <h5>لا تملك الصلاحية لتحميل هذا السجل</h5></div>')
                }
            });
        }

        $(document).delegate('.edit-form', 'submit', function (e) {
            e.preventDefault();
            var form_data = $(this).serialize();
            var tr = $(this).closest('tr').prev();
            var row = datatable.row(tr);

            _url = $(this).attr('action');
            var token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: _url,
                type: 'POST',
                data: form_data,
                success: function (result) {
                    row.data(result);
                    row.child.hide();
                    tr.removeClass('shown');
                    tr.removeClass();
                    tr.addClass('bg-' + result[9]);
                },
                error: function (request, msg, error) {
                    alert("لا تملك الصلاحية لتعديل هذا السجل");
                }
            });


        });


        $(document).delegate('.extra-form', 'submit', function (e) {
            e.preventDefault();
            var form = $(this);
            var data = form[0];
            var form_data = new FormData(data);
            var container = $(this).find('.extra-files');

            _url = $(this).attr('action');
            var token = $('meta[name="csrf-token"]').attr('content');
            $.ajax({
                url: _url,
                type: 'POST',
                data: form_data,
                contentType: false,
                processData: false,
                success: function (result) {
                    // result = JSON.parse(result);
                    full = base_url+'/' + result['path'];
                    id = result['id'];
                    container.append(
                        '<div class="file"> <a class="d-inline-block" target="_blank" href="' + full + '">' +
                        'اضغط  هنا   لفتح الملف' +
                        '</a>' +
                        '<a href="#" class="text-danger float-left btn-delete-file"' +
                        ' data-id="' + id + '"><span' +
                        ' class="fa fa-times"></span></a>' +
                        '</div>'
                    );
                },
                error: function (request, msg, error) {
                    alert("لا تملك الصلاحية لتعديل هذا السجل");
                }
            });


        });


    </script>
@endsection

